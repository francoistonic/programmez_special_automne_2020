Nb vues vidéo = CALCULATE(SUM(Mesures[fact_value]), dim_05_INDICATEUR[indicateurId]=1,dim_03_VIDEO[Categorie] <> "N\A")

Nb de vues de la veille = CALCULATE([Nb vues vidéo], PREVIOUSDAY( dim_02_DATE_PHOTO[Jour date photo]))

Nb de vue en plus sur la journée = if( ISBLANK( [Nb de vues de la veille]), BLANK(), CALCULATE([Nb vues vidéo]-[Nb de vues de la veille]))
