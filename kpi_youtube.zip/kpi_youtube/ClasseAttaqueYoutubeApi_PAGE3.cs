using Google.Apis.YouTube.v3;

public class AttaqueYoutubeApi
    {
        // id de votre chaine youtube
        private static string channelId= "UCjufGYFITwn0ZwqiA";

        //object qui permet d'attaquer l'api youtube et ses nombreuses fonctions
        private YouTubeService youtubeService = null;


        public AttaqueYoutubeApi()
        {
             youtubeService = new YouTubeService(new BaseClientService.Initializer()
            {
//paramétres créés sur https://console.developers.google.com
                ApiKey = ConfigurationManager.AppSettings["YoutubeApiKey"],
                ApplicationName = ConfigurationManager.AppSettings["YoutubeApplicationName"]
            });
        }
