# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}
 
Write-Host "AZURE FONCTION lancement début: $currentUTCtime"
Write-Host "Appel de l'api rest" 
# avec cette fonction, on appelle une fonction du Web service
Invoke-WebRequest -Uri https://pocyoutubesapplicationwebservice.azurewebsites.net/api/xxxxx/NomFonction?channelId=UCp9mU94-_J-32aClu -Method GET  -ContentType "application/json" -TimeoutSec 0
Write-Host "Appel de l'api rest AZURE effectué "

Write-Host "AZURE FONCTION lancement effectué: $currentUTCtime"
