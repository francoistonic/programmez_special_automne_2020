//fonction de recherche de toutes les vidéos d’une chaine entre deux dates
public async Task<Dictionary<string, ModelYoutubeItems>> rechercheItems(DateTime dateDebut, 
            DateTime dateFin)
        {

            Dictionary<string, ModelYoutubeItems> mapItems = new Dictionary<string, ModelYoutubeItems>();

            var searchListRequest = youtubeService.Search.List("snippet");
            searchListRequest.ChannelId = channelId;
            searchListRequest.PublishedAfter = dateDebut;
            searchListRequest.PublishedBefore = dateFin;
            //impossible de récupérer plus de 50 résultats de toute façon
            searchListRequest.MaxResults = 50;

//Appel de l’api rest
            var searchListResponse = await searchListRequest.ExecuteAsync().ConfigureAwait(false);


            // boucle sur tous les résultats
            foreach (var searchResult in searchListResponse.Items)
            {
                ModelYoutubeItems model = new ModelYoutubeItems();
//Récupération de tous les champs qui nous intéressent
                model.ChannelId = searchResult.Snippet.ChannelId;
                model.ChannelTitle = searchResult.Snippet.ChannelTitle;
                model.Description = searchResult.Snippet.Description;
                model.PublishedAt = searchResult.Snippet.PublishedAt;
                model.Title = Utiles.gestionCaracteresSpeciaux(
                    searchResult.Snippet.Title);
                model.VideoId = searchResult.Id.VideoId;
                model.Thumbnails = searchResult.Snippet.Thumbnails.Default__.Url;
 //Ajout à la liste de référence
                mapItems.Add(searchResult.Id.VideoId, model);
     }
return mapItems ;
   }}

