//Retour controleur 
return Request.CreateResponse(HttpStatusCode.OK,
                v.MapItemsGlobale.Values, Configuration.Formatters.JsonFormatter);

Pour l’écriture en base de données, entityframework est l’outil idéal, voici un exemple de code que vous pouvez utiliser :

public static int insertionYoutubeBDD
            (List<ModelYoutubeItems> modelListe, int currentThreadId)
        {
//Contexte BDD : vous avez accès aux tables, aux procédures stockées,…
            using (var context = new BDD_JFO_AZUREEntities())
            {
                try
                {
                    List<youtube_video> listInsertion = new List<youtube_video>();
                    foreach (ModelYoutubeItems model in modelListe)
                    {
//mapping champs métiers avec les champs de la table, petites transformations/conversion si besoin
                        youtube_video i = new youtube_video();
                        i.channelTitle = model.ChannelTitle;
                        i.commentCount = (model.CommentCount == null) ? 0 : (int)model.CommentCount;
                        i.description = model.Description;
                        i.dislikeCount = (model.DislikeCount == null) ? 0 : (int)model.DislikeCount;
                        i.likeCount = (model.LikeCount == null) ? 0 : (int)model.LikeCount;
                        i.thumbnails = model.Thumbnails;
                        i.Categorie = model.Category;
                        i.title = model.Title;
                        i.viewCount = (model.ViewCount == null) ? 0 : (int)model.ViewCount;
                        listInsertion.Add(i);

                    }
//ajout d’une liste complète (ne pas mettre trop d’éléments à chaque appel, trouver le juste milieu pour le temps optimal d’insertion de l’ensemble) 
                    context.youtube_video.AddRange(listInsertion);
//commit en base, on retourne le nombre de lignes insérées
                    return context.SaveChanges();
                }
