﻿using System.Threading.Tasks;

namespace csharp9
{
    public class AsyncService
    {
        public async Task<string> MyAsyncMethod() => "test";
    }
}
