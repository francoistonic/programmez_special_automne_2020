﻿namespace csharp9.TargetTyped
{
    internal class ObservableList<T>
    {
    }
}