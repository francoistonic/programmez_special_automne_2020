﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace csharp9.Tests.Unit.NullParameterCheck
{
    public class NullParameterCheckTests
    {
        [Fact]
        public void Test()
        {

        }

        public class NullService
        {
            public void SomeMethod(string name!)
            {

            }
        }

    }
}
